#pragma once
#include "FBullCowGame.h"
#include <map>
#include <time.h>
#include <vector>


// to make syntax Unreal friendly
#define TMap std::map
using FString = std::string;
using int32 = int;



FBullCowGame::FBullCowGame() { Reset(); } // Default Constructor

int32 FBullCowGame::GetCurrentTry() const { return MyCurrentTry; }
int32 FBullCowGame::GetHiddenWordLength() const { return MyHiddenWord.length(); }
bool FBullCowGame::IsGameWon() const { return bIsGameWon; }

void FBullCowGame::SetHiddenWordLength(int32 WordLength) { MyWordLength = WordLength; }

void FBullCowGame::GetRandomWordFromLength() //Set hidden word based on length and randomly chooses word from list
{
	std::srand((unsigned)time(NULL));

	std::vector<FString> WordList4 = { "give", "main", "yoga", "stop", "cave", "shoe", "tank", "camp", "peak", "zeal" };
	std::vector<FString> WordList5 = { "pause", "dairy", "voice", "march", "wagon", "fault", "baron", "scarf", "ranch", "cheat" };
	std::vector<FString> WordList6 = { "walnut", "garnet", "quiver", "teacup", "visual", "nearby", "jinxed", "devout", "zombie", "lawyer" };
	std::vector<FString> WordList7 = { "machine", "alchemy", "ketchup", "sapling", "uniform", "optimal", "halogen", "pasture", "egotism", "reality" };

	if (MyWordLength == 4)
	{
		int32 RandomWordChoice = std::rand() % WordList4.size();
		MyHiddenWord = WordList4[RandomWordChoice];
	}
	else if (MyWordLength == 5)
	{
		int32 RandomWordChoice = std::rand() % WordList5.size();
		MyHiddenWord = WordList5[RandomWordChoice];
	}
	else if (MyWordLength == 6)
	{
		int32 RandomWordChoice = std::rand() % WordList6.size();
		MyHiddenWord = WordList6[RandomWordChoice];
	}
	else if (MyWordLength == 7)
	{
		int32 RandomWordChoice = std::rand() % WordList7.size();
		MyHiddenWord = WordList7[RandomWordChoice];
	}
}

int32 FBullCowGame::GetMaxTries() const //Set max tries based on length
{
	TMap<int32, int32> WordLengthToMaxTries{ {4,7}, {5,10}, {6,16}, {7,20} };
	return WordLengthToMaxTries[MyHiddenWord.length()];
}

void FBullCowGame::Reset()
{
	MyCurrentTry = 1;
	bIsGameWon = false;
	return;
}

EGuessStatus FBullCowGame::CheckGuessValidity(FString Guess) const
{
	if (!IsIsogram(Guess))
	{
		return EGuessStatus::Not_Isogram;
	}
	else if (!IsLowerCase(Guess))
	{
		return EGuessStatus::Not_Lowercase;
	}
	else if (Guess.length() != GetHiddenWordLength())
	{
		return EGuessStatus::Wrong_Length;
	}
	else
	{
		return EGuessStatus::OK;
	}
}

//receives a VALID guess, increments turn, and returns count
FBullCowCount FBullCowGame::SubmitValidGuess(FString Guess)
{
	MyCurrentTry++;
	FBullCowCount BullCowCount;
	int32 WordLength = GetHiddenWordLength(); // assuming same length as guess

	//loop through all letters in a guess
	for (int32 GChar = 0; GChar < WordLength; GChar++)
	{
		//compare letters against the hidden word
		for (int32 MHWChar = 0; MHWChar < WordLength; MHWChar++)
		{
			//if they match then
			if (Guess[GChar] == MyHiddenWord[MHWChar])
			{
				if (GChar == MHWChar) //increment bulls if they are in the same place
				{
					BullCowCount.Bulls++;
				}
				else //increment cows if not
				{
					BullCowCount.Cows++;
				}
			}
		}
	}
	if (BullCowCount.Bulls == WordLength)
	{
		bIsGameWon = true;
	}
	else
	{
		bIsGameWon = false;
	}

	return BullCowCount;
}

bool FBullCowGame::IsIsogram(FString Word) const
{
	//treat 0 1nd 1 letter words as isograms
	if (Word.length() <= 1) { return true; }

	TMap<char, bool> LetterSeen; //check each letter
	for (auto Letter : Word) //for all letters of the word
	{
		Letter = tolower(Letter); //handle mixed case
		if (LetterSeen[Letter]) //if letter is already in map as true then return not isogram
		{
			return false;
		}
		else //add the letter to the map as true
		{
			LetterSeen[Letter] = true;
		}
	}

	return true; //for example incases where \0 is entered
}

bool FBullCowGame::IsLowerCase(FString Word) const
{
	for (auto Letter : Word) //if not lowersase return false
	{
		if (!islower(Letter)) { return false; }
	}
	return true;
}
